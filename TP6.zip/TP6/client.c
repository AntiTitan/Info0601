/*
Reception: seulement le type TYPE_TRIEUR
Envoie:
    TYPE_ENREGISTRER : une var de type enregistre_t
    TYPE_CLIENT : une var msgClient_t
*/