#ifndef FVOITURES_H
#define FVOITURES_H

#include "struct.h"

int alea(int a, int b);
int recupererFile(int CLE_F);
int recupererMemoire(int CLE_M);
int recupererSemaphores(int CLE_S);

#endif